# Nexora Recorder Pro — Phase 1 (design system)
Open the folder in Android Studio (Koala or newer, JDK 17). Let Gradle sync (needs internet once).
Run on a device/emulator (Android 8.0+), or Build > Build APK(s).
Phase 1 has no permissions and no recording yet.
