package com.nexora.recorderpro.ui.theme

import androidx.compose.ui.graphics.Color

val NexoraBlack = Color(0xFF05070D)
val NexoraNavy = Color(0xFF0B1220)
val NexoraNavySurface = Color(0xFF111B2E)
val NexoraNavyHigh = Color(0xFF1A2742)
val ElectricBlue = Color(0xFF2F7BFF)
val SoftBlue = Color(0xFF6AA4FF)
val Cyan = Color(0xFF22D3EE)
val Success = Color(0xFF22C55E)
val Warning = Color(0xFFF59E0B)
val Danger = Color(0xFFEF4444)
val TextPrimary = Color(0xFFF2F6FF)
val TextSecondary = Color(0xFF9AA8C4)

val LightBg = Color(0xFFF4F7FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE6ECF7)
val LightText = Color(0xFF0B1220)
val LightTextSecondary = Color(0xFF51607C)
