package com.nexora.recorderpro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val DarkScheme = darkColorScheme(
    primary = ElectricBlue, onPrimary = TextPrimary,
    secondary = Cyan, onSecondary = NexoraBlack,
    background = NexoraBlack, onBackground = TextPrimary,
    surface = NexoraNavy, onSurface = TextPrimary,
    surfaceVariant = NexoraNavySurface, onSurfaceVariant = TextSecondary,
    error = Danger,
)
private val LightScheme = lightColorScheme(
    primary = ElectricBlue, onPrimary = LightSurface,
    secondary = Cyan, onSecondary = LightText,
    background = LightBg, onBackground = LightText,
    surface = LightSurface, onSurface = LightText,
    surfaceVariant = LightSurfaceVariant, onSurfaceVariant = LightTextSecondary,
    error = Danger,
)
private val NexoraShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
)

@Composable
fun NexoraTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        typography = NexoraTypography,
        shapes = NexoraShapes,
        content = content,
    )
}
