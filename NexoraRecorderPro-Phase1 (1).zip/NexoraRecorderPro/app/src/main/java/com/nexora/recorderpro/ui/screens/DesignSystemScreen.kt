package com.nexora.recorderpro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.nexora.recorderpro.R
import com.nexora.recorderpro.ui.components.*
import com.nexora.recorderpro.ui.theme.*

@Composable
fun DesignSystemScreen() {
    var recording by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(cs.background, cs.surface, cs.background)))
    ) {
        Column(
            Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 640.dp)
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineMedium, color = cs.onBackground)
            Text(stringResource(R.string.tagline), style = MaterialTheme.typography.bodyMedium, color = Cyan)

            GlassCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    StatusChip(if (recording) RecState.Recording else RecState.Ready)
                    Text("NEXORA", style = MaterialTheme.typography.titleMedium, color = cs.onSurface)
                }
                Spacer(Modifier.height(20.dp))
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("00:00:00", style = MaterialTheme.typography.displayLarge.copy(fontFamily = FontFamily.Monospace), color = SoftBlue)
                    Text(
                        stringResource(if (recording) R.string.recording_now else R.string.ready_to_record),
                        style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, textAlign = TextAlign.Center,
                    )
                    RecordButton(
                        isRecording = recording,
                        description = stringResource(if (recording) R.string.stop_recording else R.string.start_recording),
                        onClick = { recording = !recording },
                    )
                }
            }

            SectionTitle(R.string.section_buttons)
            NexoraPrimaryButton(
                text = stringResource(if (recording) R.string.stop_recording else R.string.start_recording),
                onClick = { recording = !recording },
                danger = recording,
                modifier = Modifier.fillMaxWidth(),
            )

            SectionTitle(R.string.section_chips)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { RecState.values().forEach { StatusChip(it) } }

            SectionTitle(R.string.section_tiles)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                QuickTile(stringResource(R.string.tile_videos), "▶", {}, Modifier.weight(1f))
                QuickTile(stringResource(R.string.tile_audio), "♪", {}, Modifier.weight(1f))
                QuickTile(stringResource(R.string.tile_gaming), "◆", {}, Modifier.weight(1f))
            }

            Text(stringResource(R.string.phase1_note), style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun SectionTitle(res: Int) =
    Text(stringResource(res), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground)
