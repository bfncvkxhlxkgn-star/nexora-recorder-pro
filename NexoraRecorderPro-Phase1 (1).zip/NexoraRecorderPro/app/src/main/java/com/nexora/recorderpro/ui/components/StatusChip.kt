package com.nexora.recorderpro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.nexora.recorderpro.R
import com.nexora.recorderpro.ui.theme.*

enum class RecState(val color: Color, val labelRes: Int) {
    Ready(Success, R.string.status_ready),
    Recording(Danger, R.string.status_recording),
    Paused(Warning, R.string.status_paused),
    Error(Danger, R.string.status_error),
}

@Composable
fun StatusChip(state: RecState, modifier: Modifier = Modifier) {
    Text(
        text = stringResource(state.labelRes),
        style = MaterialTheme.typography.labelSmall,
        color = state.color,
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(state.color.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
    )
}
